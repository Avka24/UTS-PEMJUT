﻿namespace bukutelpon
{


    partial class DataSet1
    {
    }
}
