﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bukutelpon
{
    public partial class BukuTelepon : Form
    {
        DataTable kontak = new DataTable();
        bool editing = false;
        public BukuTelepon()
        {
            InitializeComponent();
        }

        private void BukuTelepon_Load(object sender, EventArgs e)
        {
            kontak.Columns.Add("Nama");
            kontak.Columns.Add("Nomor");
            kontak.Columns.Add("Email");
            kontak.Columns.Add("Alamat");

            //set data
            kontakDataGrid.DataSource = kontak;
        }

        private void btnBaru_Click(object sender, EventArgs e)
        {
            tbNama.Text = "";
            tbNomor.Text = "";
            tbEmail.Text = "";
            tbAlamat.Text = "";
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            tbNama.Text = kontak.Rows[kontakDataGrid.CurrentCell.RowIndex].ItemArray[0].ToString();
            tbNomor.Text = kontak.Rows[kontakDataGrid.CurrentCell.RowIndex].ItemArray[1].ToString();
            tbEmail.Text = kontak.Rows[kontakDataGrid.CurrentCell.RowIndex].ItemArray[2].ToString();
            tbAlamat.Text = kontak.Rows[kontakDataGrid.CurrentCell.RowIndex].ItemArray[3].ToString();
            editing = true;
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            if (editing)
            {
                kontak.Rows[kontakDataGrid.CurrentCell.RowIndex]["Nama"] = tbNama.Text;
                kontak.Rows[kontakDataGrid.CurrentCell.RowIndex]["Nomor"] = tbNomor.Text;
                kontak.Rows[kontakDataGrid.CurrentCell.RowIndex]["Email"] = tbEmail.Text;
                kontak.Rows[kontakDataGrid.CurrentCell.RowIndex]["Alamat"] = tbAlamat.Text;
            }
            else
            {
                kontak.Rows.Add(tbNama.Text, tbNomor.Text, tbEmail.Text, tbAlamat.Text);
            }

            btnBaru_Click(sender, e);
            editing = false;
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            try
            {
                kontak.Rows[kontakDataGrid.CurrentCell.RowIndex].Delete();
            }
            catch (Exception ex) {Console.WriteLine("Bukan baris yang tidak valid"); }
        }

        private void kontakDataGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            tbNama.Text = kontak.Rows[kontakDataGrid.CurrentCell.RowIndex].ItemArray[0].ToString();
            tbNomor.Text = kontak.Rows[kontakDataGrid.CurrentCell.RowIndex].ItemArray[1].ToString();
            tbEmail.Text = kontak.Rows[kontakDataGrid.CurrentCell.RowIndex].ItemArray[2].ToString();
            tbAlamat.Text = kontak.Rows[kontakDataGrid.CurrentCell.RowIndex].ItemArray[3].ToString();
            editing = true;
        }

        private void tbNama_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
