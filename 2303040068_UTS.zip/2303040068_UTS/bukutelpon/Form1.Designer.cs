﻿namespace bukutelpon
{
    partial class BukuTelepon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnBaru = new System.Windows.Forms.Button();
            this.tbNama = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbNomor = new System.Windows.Forms.TextBox();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.tbAlamat = new System.Windows.Forms.TextBox();
            this.Nomor = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.Label();
            this.Alamat = new System.Windows.Forms.Label();
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnSimpan = new System.Windows.Forms.Button();
            this.btnHapus = new System.Windows.Forms.Button();
            this.kontakDataGrid = new System.Windows.Forms.DataGridView();
            this.dataBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new bukutelpon.DataSet1();
            this.dataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.kontakDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBaru
            // 
            this.btnBaru.Location = new System.Drawing.Point(954, 13);
            this.btnBaru.Margin = new System.Windows.Forms.Padding(4);
            this.btnBaru.Name = "btnBaru";
            this.btnBaru.Size = new System.Drawing.Size(100, 28);
            this.btnBaru.TabIndex = 4;
            this.btnBaru.Text = "Baru";
            this.btnBaru.UseVisualStyleBackColor = true;
            this.btnBaru.Click += new System.EventHandler(this.btnBaru_Click);
            // 
            // tbNama
            // 
            this.tbNama.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dataBindingSource, "Nama", true));
            this.tbNama.Location = new System.Drawing.Point(122, 13);
            this.tbNama.Multiline = true;
            this.tbNama.Name = "tbNama";
            this.tbNama.Size = new System.Drawing.Size(825, 28);
            this.tbNama.TabIndex = 0;
            this.tbNama.TextChanged += new System.EventHandler(this.tbNama_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nama:";
            // 
            // tbNomor
            // 
            this.tbNomor.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dataBindingSource1, "Nomor", true));
            this.tbNomor.Location = new System.Drawing.Point(122, 47);
            this.tbNomor.Multiline = true;
            this.tbNomor.Name = "tbNomor";
            this.tbNomor.Size = new System.Drawing.Size(825, 28);
            this.tbNomor.TabIndex = 1;
            // 
            // tbEmail
            // 
            this.tbEmail.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dataBindingSource1, "Email", true));
            this.tbEmail.Location = new System.Drawing.Point(122, 81);
            this.tbEmail.Multiline = true;
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(825, 28);
            this.tbEmail.TabIndex = 2;
            // 
            // tbAlamat
            // 
            this.tbAlamat.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dataBindingSource1, "Alamat", true));
            this.tbAlamat.Location = new System.Drawing.Point(122, 115);
            this.tbAlamat.Multiline = true;
            this.tbAlamat.Name = "tbAlamat";
            this.tbAlamat.Size = new System.Drawing.Size(825, 70);
            this.tbAlamat.TabIndex = 3;
            // 
            // Nomor
            // 
            this.Nomor.AutoSize = true;
            this.Nomor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nomor.Location = new System.Drawing.Point(12, 55);
            this.Nomor.Name = "Nomor";
            this.Nomor.Size = new System.Drawing.Size(66, 20);
            this.Nomor.TabIndex = 6;
            this.Nomor.Text = "Nomor:";
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email.Location = new System.Drawing.Point(12, 89);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(58, 20);
            this.Email.TabIndex = 7;
            this.Email.Text = "Email:";
            // 
            // Alamat
            // 
            this.Alamat.AutoSize = true;
            this.Alamat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alamat.Location = new System.Drawing.Point(12, 123);
            this.Alamat.Name = "Alamat";
            this.Alamat.Size = new System.Drawing.Size(70, 20);
            this.Alamat.TabIndex = 8;
            this.Alamat.Text = "Alamat:";
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(954, 47);
            this.btnLoad.Margin = new System.Windows.Forms.Padding(4);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(100, 28);
            this.btnLoad.TabIndex = 5;
            this.btnLoad.Text = "Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnSimpan
            // 
            this.btnSimpan.Location = new System.Drawing.Point(954, 81);
            this.btnSimpan.Margin = new System.Windows.Forms.Padding(4);
            this.btnSimpan.Name = "btnSimpan";
            this.btnSimpan.Size = new System.Drawing.Size(100, 28);
            this.btnSimpan.TabIndex = 6;
            this.btnSimpan.Text = "Simpan";
            this.btnSimpan.UseVisualStyleBackColor = true;
            this.btnSimpan.Click += new System.EventHandler(this.btnSimpan_Click);
            // 
            // btnHapus
            // 
            this.btnHapus.Location = new System.Drawing.Point(954, 115);
            this.btnHapus.Margin = new System.Windows.Forms.Padding(4);
            this.btnHapus.Name = "btnHapus";
            this.btnHapus.Size = new System.Drawing.Size(100, 70);
            this.btnHapus.TabIndex = 7;
            this.btnHapus.Text = "Hapus";
            this.btnHapus.UseVisualStyleBackColor = true;
            this.btnHapus.Click += new System.EventHandler(this.btnHapus_Click);
            // 
            // kontakDataGrid
            // 
            this.kontakDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.kontakDataGrid.BackgroundColor = System.Drawing.SystemColors.ButtonShadow;
            this.kontakDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.kontakDataGrid.Location = new System.Drawing.Point(12, 191);
            this.kontakDataGrid.Name = "kontakDataGrid";
            this.kontakDataGrid.Size = new System.Drawing.Size(1043, 351);
            this.kontakDataGrid.TabIndex = 8;
            this.kontakDataGrid.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.kontakDataGrid_CellDoubleClick);
            // 
            // dataBindingSource1
            // 
            this.dataBindingSource1.DataMember = "Data";
            this.dataBindingSource1.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataBindingSource
            // 
            this.dataBindingSource.DataMember = "Data";
            this.dataBindingSource.DataSource = this.dataSet1;
            // 
            // BukuTelepon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.kontakDataGrid);
            this.Controls.Add(this.btnHapus);
            this.Controls.Add(this.btnSimpan);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.Alamat);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.Nomor);
            this.Controls.Add(this.tbAlamat);
            this.Controls.Add(this.tbEmail);
            this.Controls.Add(this.tbNomor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbNama);
            this.Controls.Add(this.btnBaru);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BukuTelepon";
            this.Text = "Buku Telepon";
            this.Load += new System.EventHandler(this.BukuTelepon_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kontakDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBaru;
        private System.Windows.Forms.TextBox tbNama;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbNomor;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.TextBox tbAlamat;
        private System.Windows.Forms.Label Nomor;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.Label Alamat;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnSimpan;
        private System.Windows.Forms.Button btnHapus;
        private System.Windows.Forms.DataGridView kontakDataGrid;
        private System.Windows.Forms.BindingSource dataBindingSource;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource dataBindingSource1;
    }
}

